import { MapPin, Navigation, Filter, Star, X } from 'lucide-react';
import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { YupCard } from '../YupCard';
import { Badge } from '../ui/badge';
import { ImageWithFallback } from '../figma/ImageWithFallback';

const spots = [
  {
    id: 1,
    name: 'Naga Cable Park',
    type: 'Cable Park',
    distance: '1.2 km',
    rating: 4.9,
    reviews: 342,
    image: 'https://images.unsplash.com/photo-1752170053218-5f05ccfbee4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    lat: -22.703,
    lng: -46.984,
    featured: true,
  },
  {
    id: 2,
    name: 'Lagoa de Marapendi',
    type: 'Boat Ride',
    distance: '3.7 km',
    rating: 4.6,
    reviews: 89,
    image: 'https://images.unsplash.com/photo-1632192661889-85748ae575d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    lat: -23.590,
    lng: -46.650,
  },
  {
    id: 3,
    name: 'Represa Guarapiranga',
    type: 'Boat Ride',
    distance: '5.1 km',
    rating: 4.7,
    reviews: 156,
    image: 'https://images.unsplash.com/photo-1610665893833-3692e97e1ee8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    lat: -23.583,
    lng: -46.663,
  },
];

export function MapScreen() {
  const [drawerOpen, setDrawerOpen] = useState(true);
  const [drawerExpanded, setDrawerExpanded] = useState(false);
  const mapRef = useRef<HTMLDivElement>(null);

  const handleMapInteraction = () => {
    setDrawerOpen(false);
    setDrawerExpanded(false);
  };

  const toggleDrawer = () => {
    if (!drawerOpen) {
      setDrawerOpen(true);
      setDrawerExpanded(false);
    } else if (!drawerExpanded) {
      setDrawerExpanded(true);
    } else {
      setDrawerExpanded(false);
    }
  };

  return (
    <div className="relative h-screen w-full bg-[#0D0D0D] overflow-hidden">
      {/* Full Screen Map */}
      <div 
        ref={mapRef}
        className="absolute inset-0 bg-gradient-to-br from-[#1A1A1A] via-[#27272A] to-[#1A1A1A]"
        onTouchStart={handleMapInteraction}
        onMouseDown={handleMapInteraction}
      >
        {/* Map Grid Pattern (optional) */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(to right, #FF6B00 1px, transparent 1px),
              linear-gradient(to bottom, #FF6B00 1px, transparent 1px)
            `,
            backgroundSize: '40px 40px'
          }}
        />

        {/* Spot Markers on Map */}
        {spots.map((spot, index) => (
          <motion.div
            key={spot.id}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
            className="absolute"
            style={{
              top: `${30 + index * 20}%`,
              left: `${25 + index * 25}%`,
            }}
            onClick={() => {
              setDrawerOpen(true);
              setDrawerExpanded(false);
            }}
          >
            <div className="relative cursor-pointer group">
              <div className="w-10 h-10 bg-[#FF6B00] rounded-full flex items-center justify-center shadow-lg border-2 border-white group-hover:scale-110 transition-transform">
                <MapPin size={20} className="text-white" />
              </div>
              {/* Pulse animation */}
              <div className="absolute inset-0 w-10 h-10 bg-[#FF6B00] rounded-full animate-ping opacity-20" />
            </div>
          </motion.div>
        ))}

        {/* Top Right Controls */}
        <div className="absolute top-4 right-4 flex flex-col gap-2 z-20">
          <button 
            className="w-12 h-12 bg-[#1A1A1A] border border-[#27272A] backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-lg hover:bg-[#27272A] transition-colors"
            onClick={(e) => e.stopPropagation()}
          >
            <Filter size={20} className="text-[#F5F5F5]" />
          </button>
        </div>

        {/* Bottom Right - Current Location Button */}
        <div className="absolute bottom-24 right-4 z-20">
          <button 
            className="w-14 h-14 bg-[#FF6B00] rounded-full flex items-center justify-center shadow-lg hover:bg-[#FF8533] transition-colors"
            onClick={(e) => {
              e.stopPropagation();
              // Center on user location
            }}
          >
            <Navigation size={24} className="text-white" />
          </button>
        </div>
      </div>

      {/* Spots Drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <motion.div
            initial={{ y: '100%' }}
            animate={{ 
              y: drawerExpanded ? '10%' : 'calc(100% - 280px)'
            }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="absolute inset-x-0 bottom-0 z-30"
            style={{ height: '90%' }}
          >
            <div className="h-full bg-[#0D0D0D] rounded-t-3xl shadow-2xl border-t border-[#27272A] flex flex-col">
              {/* Drawer Handle */}
              <div 
                className="pt-3 pb-4 cursor-pointer"
                onClick={toggleDrawer}
              >
                <div className="w-12 h-1.5 bg-[#27272A] rounded-full mx-auto" />
              </div>

              {/* Close Button */}
              <button
                onClick={() => setDrawerOpen(false)}
                className="absolute top-4 right-4 w-8 h-8 bg-[#27272A] rounded-full flex items-center justify-center hover:bg-[#3A3A3A] transition-colors z-10"
              >
                <X size={16} className="text-[#F5F5F5]" />
              </button>

              {/* Drawer Content */}
              <div className="flex-1 overflow-y-auto px-4 pb-20">
                <div className="mb-6">
                  <h3 className="text-[#F5F5F5] mb-1">Spots Próximos de Você</h3>
                  <p className="text-[#9CA3AF] text-[14px]">{spots.length} locais encontrados</p>
                </div>

                <div className="space-y-3">
                  {spots.map((spot) => (
                    <YupCard key={spot.id} className={`hover:border-[#FF6B00]/50 transition-colors cursor-pointer ${spot.featured ? 'border-[#FF6B00] bg-gradient-to-br from-[#FF6B00]/5 to-transparent' : ''}`}>
                      <div className="flex gap-3">
                        <div className="w-20 h-20 bg-[#27272A] rounded-xl overflow-hidden flex-shrink-0">
                          <ImageWithFallback
                            src={spot.image}
                            alt={spot.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h4 className="text-[#F5F5F5] text-[15px]">{spot.name}</h4>
                                {spot.featured && (
                                  <Badge className="bg-[#FF6B00] text-white border-0 text-[9px] px-1.5 py-0">
                                    DESTAQUE
                                  </Badge>
                                )}
                              </div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <Badge className="bg-[#27272A] text-[#9CA3AF] border border-[#374151] text-[11px] px-2 py-0">
                                  {spot.type}
                                </Badge>
                                <span className="text-[#9CA3AF] text-[12px]">{spot.distance}</span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-1">
                            <Star size={13} className="text-[#FF6B00] fill-[#FF6B00]" />
                            <span className="text-[#F5F5F5] text-[13px]">{spot.rating}</span>
                            <span className="text-[#9CA3AF] text-[11px]">({spot.reviews})</span>
                          </div>
                        </div>
                      </div>
                    </YupCard>
                  ))}
                </div>

                {/* Add Spot CTA */}
                <YupCard className="bg-gradient-to-r from-[#FF6B00]/10 to-[#FF8533]/10 border-[#FF6B00]/30 text-center cursor-pointer hover:border-[#FF6B00] transition-colors mt-4">
                  <MapPin size={28} className="text-[#FF6B00] mx-auto mb-2" />
                  <h4 className="text-[#F5F5F5] mb-1 text-[15px]">Adicionar Novo Spot</h4>
                  <p className="text-[#9CA3AF] text-[13px]">
                    Conhece um lugar incrível? Compartilhe com a comunidade!
                  </p>
                </YupCard>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Button to Show Drawer (when hidden) */}
      <AnimatePresence>
        {!drawerOpen && (
          <motion.button
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            onClick={() => setDrawerOpen(true)}
            className="absolute bottom-24 left-1/2 -translate-x-1/2 z-20 px-6 py-3 bg-[#FF6B00] text-white rounded-full shadow-lg hover:bg-[#FF8533] transition-colors flex items-center gap-2"
          >
            <MapPin size={18} />
            <span className="text-[14px]">Ver {spots.length} Spots</span>
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
