
  # Y'UP App Screen Design

  This is a code bundle for Y'UP App Screen Design. The original project is available at https://www.figma.com/design/f9lP8mTyJnzFJzxJqLc5jV/Y-UP-App-Screen-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  